<?php ?>
  
  <script src="application/static/js/jquery.min.js"></script>

    </body>

</html>