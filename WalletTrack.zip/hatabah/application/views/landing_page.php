<html>
  <head>
    <title>Welcome to Hatabah!</title>
  </head>

  <body>
		<span id="signinButton">
	  	<span
	    	class="g-signin"
	    	data-callback="signinCallback"
	    	data-clientid="530931383084.apps.googleusercontent.com"
	    	data-cookiepolicy="single_host_origin"
	    	data-requestvisibleactions="http://schemas.google.com/AddActivity"
	    	data-scope="https://www.googleapis.com/auth/plus.login">
	  	</span>
		</span>	

	<script src="application/static/js/jquery.min.js"></script>
	<script src="application/static/js/glogin.js"></script>

</body>

</html>