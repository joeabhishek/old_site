<!DOCTYPE html>
<html lang="en">
  <head>
    <title> Hatbah | Home </title>
    <link rel="stylesheet" type="text/css" href="../application/static/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../application/static/css/m-buttons.min.css">
    <link rel="stylesheet" type="text/css" href="../application/static/css/m-icons.min.css">
    <link rel="stylesheet" type="text/css" href="../application/static/css/datepicker.css">
    <link rel="stylesheet" type="text/css" href="../application/static/css/bootstrap-notify.css">
    <link rel="stylesheet" type="text/css" href="../application/static/css/home.css">

  </head>

  <body>
  <div id="headerContainer">
    <div class="hero-unit">
      <h1>Hatabah!</h1>
      <p>Managing expenses made, simple. Stupid.</p>
    </div>
  </div>

  <div class="container-fluid">

    <div class="row-fluid" id="header">
      <div class="span4">
        <a id="createbtn" class="m-btn blue">Create Expense</a>
      </div>
      <div class="offset4 span4 pull-right">
        <p>
          hello, <?php echo $username ?> 
          <img src="<?php echo $imgurl ?>" />
        </p>
      </div>
    </div>

    <div class="row-fluid">
      <div class="span3 leftpane">
        <h3> Recent Expenses </h3>
         <ul class="nav nav-list">
          <?php foreach ($latest as $item):?>
            <li><a id="<?php echo $item->expid; ?>"><?php echo $item->title;?></a></li>
          <?php endforeach;?>
        </ul>

      </div> 
      <div class="span7 rightpane">
        <div id="contentDiv">
          <h3 id="contentHeader"></h3>
          <p id="date"></p>
          <table class="table table-striped">
            <tbody id="tableBody"></tbody>
          </table>
        </div>
        <form id="createform" action="" method="post">
          <fieldset>
          <legend>Create a new expense</legend>
          <label for="title">Expense Title</label>
          <input id="title" name="exptitle" type="text" />
          <label for="date"> Date </label>
          <div class="input-append date" id="datepicker" >
            <input id="date" type="text" >
            <span class="add-on"><i class="icon-th"></i></span>
          </div>
          <label> Add expense items</label>
          <!-- sheepIt Form -->
          <div id="sheepItForm">
           
            <!-- Form template-->
            <div id="sheepItForm_template">
              <input id="sheepItForm#index#fname" type="text" name="expense[fnames][#index#][fname]" placeholder="Enter a name" />
              <input id="sheepItForm#index#amount" type="text" name="expense[amounts][#index#][amount]" placeholder="Enter Amount" />
              <select id="sheepItForm#index#details" name="fsdf">
                <option value="take">Lent Me</option>
                <option value="give">I Lent</option>
              </select>
              <!-- <a id="sheepItForm_remove_current">
                <img class="delete" src="../application/static/img/cross.png" width="16" height="16" border="0">
              </a> -->

            </div>
            <!-- /Form template-->
             
            <!-- No forms template -->

            <div id="sheepItForm_noforms_template" class="alert alert-error">You need add atleast one item.</div>
            <!-- /No forms template-->
             
            <!-- Controls -->
            <div id="sheepItForm_controls">
              <p>
              <a id="sheepItForm_add" class="m-btn mini blue"><i class="icon-plus"></i> Add </a>
              <a id="sheepItForm_remove_last" class="m-btn mini red"><i class="icon-trash"></i> Delete </a>
              <input type="button" class="m-btn green submitbtn" name="submit" value="Create"/>
              </p>
            </div>
            <!-- /Controls -->
             
          </div>
          <!-- /sheepIt Form -->
        </fieldset>
        </form>
        <div class='notifications center'></div>
      </div>
    </div>
  </div>

    <script src="../application/static/js/jquery.min.js"></script>
    <script src="../application/static/js/bootstrap-datepicker.js"></script>
    <script src="../application/static/js/jquery.sheepit.min.js"></script>
    <script src="../application/static/js/bootstrap-notify.js"></script>
    <script src="../application/static/js/home.js"></script>

  </body>


</html>