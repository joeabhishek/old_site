<?php

class Expitems_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  function addExpItem($expid, $name, $amount, $type) {
    $data = array(
               'expid' => $expid,
               'name' => $name,
               'amount' => (int) $amount,
               'type' => $type

            );

    $this->db->insert('expitems', $data); 
  }

  function getExpItems($expid) {
    $expItem = $this->db->get_where('expitems', array('expid' => $expid));
    return $expItem->result();
  }
}

?>