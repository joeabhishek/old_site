<?php

class Expsheet_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  function addExpSheet($expid, $title, $expdate) {
    $data = array(
               'expid' => $expid,
               'title' => $title,
               'date' =>  date("Y-m-d", strtotime($expdate))
            );

    $this->db->insert('expsheet', $data); 
  }

  function getExpSheet($expid) {
    $expSheet = $this->db->get_where('expsheet', array('expid' => $expid));
    return $expSheet->result();
  }

  function getLatest(){
     $query = $this->db->get('expsheet', 10);
     return $query->result();
  }
}

?>