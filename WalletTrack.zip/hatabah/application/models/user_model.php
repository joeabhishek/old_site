<?php

class User_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  function insertUser($username, $imageurl) {
    $data = array(
               'username' => $username,
               'imageurl' => $imageurl
            );

    $this->db->insert('users', $data); 
  }

  function getUser($username) {
    $userInfo = $this->db->get_where('users', array('username' => $username));
    return $userInfo->result();
  }
}

?>