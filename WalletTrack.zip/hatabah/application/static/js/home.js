$(document).ready(function() {
     
    $('#createform').hide()
    $('#contentDiv').hide();
    $('#datepicker').datepicker({
        format: 'dd-mm-yyyy'
    });

    var sheepItForm = $('#sheepItForm').sheepIt({
        separator: '',
        allowRemoveLast: true,
        allowRemoveCurrent: true,
        allowRemoveAll: true,
        allowAdd: true,
        allowAddN: true,
        maxFormsCount: 10,
        minFormsCount: 0,
        iniFormsCount: 1
    });

    $("#createbtn").click(function(){
        $('#contentDiv').hide();
        $('#createform').show();

    });



    $(".submitbtn").click(function() {  
        var inpItems = $('#createform input');
        var title = inpItems[0].value;
        var date = inpItems[1].value;
        
        var expItems = [];
        for(var i=2; i<inpItems.length-1; i=i+2){
            expItems.push({
                'name': inpItems[i].value,
                'amount': inpItems[i+1].value
            });
        }
       
       var idx = 0; 
       $('select').each(function(){
            expItems[idx]['type'] = $(this).val();
            idx++;
       });
       
       $.ajax ({
          type: "POST",
          url: "/hatabah/index.php/createexpense",
          data: { title: title, date: date, expItems: expItems}
       }).done(function(data){
              $('#createform').hide()
/*              $('.center').notify({
                message: { text: 'Aw yeah, It works!' },
                type: "info"
              }).show();
*/        location.reload(true);
          });
    }); //on create button click

    $(".nav-list li").click(function(){
        $('#contentDiv').show();
        $(".nav-list").find("li").each(function(i) {
            $(this).removeClass("active");
        });

        $(this).addClass("active");
        $("#createform").hide();

        var expid = $(this).find('a').attr('id');
        $.ajax({
          type: "GET",
          url: "/hatabah/index.php/getexpense",
          data: {expid: expid}
        }).done(function(data){
           data = JSON.parse(data);
           $tableBody = $("#tableBody");
           $tableBody.empty();
           $("#contentHeader").html(data['title']);
           date = "<i class='icon-time'></i> " + data['date'];
           $("#date").html(date);
           $(".icon-time").show();           
           $.each(data['items'], function(i,v){
            $.each($(this), function(idx,val){
              row = "<tr><td>" + val['name'] + "</td>";
              row = row + "<td>" + val['amount'] + "</td>";
              if(val['type'] == "give")
                row = row + "<td><span class='label label-success'>Owes You</span></td></tr>";
              else
                row = row + "<td><span class='label label-important'>You Owe</span></td></tr>";
              $tableBody.append(row);
            });
          });
        });
    }); 
});
