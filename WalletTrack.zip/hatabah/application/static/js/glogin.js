function signinCallback(authResult) {
  if (authResult['access_token']) {
    // Successfully authorized
    $.ajax ({
      type: "POST",
      url: "/hatabah/index.php/createsession",
      data: { access_token: authResult['access_token'] }
    }).done(function(data){
       window.location = "/hatabah/index.php/home";
    });
   // 
  } else if (authResult['error']) {
    // There was an error.
    // Possible error codes:
    //   "access_denied" - User denied access to your app
    //   "immediate_failed" - Could not automatially log in the user
    // console.log('There was an error: ' + authResult['error']);
  }
}

$(document).ready(function(){
  (function() {
   var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
   po.src = 'https://apis.google.com/js/client:plusone.js';
   var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
});