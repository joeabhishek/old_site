<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createexpense extends CI_Controller {

  public function index()
  {
     $this->load->model('expsheet_model');
     $this->load->model('expitems_model');

     $randID = rand();
     $expid = "exp-" . $randID;


     $this->expsheet_model->addExpSheet($expid, $this->input->post('title'), $this->input->post('date'));

     foreach ($this->input->post('expItems') as $item) {
        $this->expitems_model->addExpItem($expid, $item['name'], $item['amount'], $item['type']);
     }

     echo $expid;
  }
}