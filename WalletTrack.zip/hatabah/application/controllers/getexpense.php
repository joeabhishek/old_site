<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Getexpense extends CI_Controller {

  public function index()
  {
    
    $this->load->model('user_model');
    $this->load->model('expsheet_model');
    $this->load->model('expitems_model');

    $result;

    $expid = $this->input->get('expid');
    $expInfo = $this->expsheet_model->getExpSheet($expid);
    $expItems = $this->expitems_model->getExpItems($expid);

    $result['title'] = $expInfo[0]->title;
    $result['date'] = $expInfo[0]->date;
    $result['items'] = $expItems;
    $res = json_encode($result);
    echo $res;
  }
}
