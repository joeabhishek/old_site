<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

  public function index()
  {
    session_start();
    
    $this->load->model('user_model');
    $this->load->model('expsheet_model');

    $userInfo = $this->user_model->getUser($_SESSION['username']);
    if(count($userInfo) === 0)
      $this->user_model->insertUser($_SESSION['username'], $_SESSION['image']);
   
    $data['username'] = $_SESSION['username'];
    $data['imgurl'] = $_SESSION['image'];

    $data['latest'] = $this->expsheet_model->getLatest();
    $this->load->view('home_page', $data);
  }
}
