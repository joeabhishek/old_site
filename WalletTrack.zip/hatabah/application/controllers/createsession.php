<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createsession extends CI_Controller {

  public function index()
  {
    session_start();
    $_SESSION['access_token'] = $this->input->post('access_token');
    $gUrl = "https://www.googleapis.com/plus/v1/people/me/?access_token=" . $this->input->post('access_token');
    $userInfo = file_get_contents($gUrl);
    $res = json_decode($userInfo);
    $_SESSION['username'] = $res->displayName;
    $_SESSION['image'] = $res->image->url;
    
  }
}