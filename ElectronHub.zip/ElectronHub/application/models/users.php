<?php
 
class users extends CI_Model{
		
	public function __construct() {
		parent::__construct();
		$this->load->database();			
	}
	
	public function getUserByEmail($email) {
		$query=$this->db->get_where('users',array('email'=>$email));
		return $query->result();
	}
	
	public function getUserById($userid) {
		$query=$this->db->get_where('users',array('id'=>$userid));
		return $query->result();
	}
	
	public function getUsers(){
		$query=$this->db->get('users');
		return $query->result();
	}
}
