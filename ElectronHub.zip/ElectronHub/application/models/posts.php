<?php

class Posts extends CI_Model {
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->library('session');	
	}
	
	public function createPost($username,$posttext)
	{
		$insertdata = array(
				'userid' => $this->session->userdata('userid'),
				'username'=> $username ,
				'post_text' => $posttext ,
				'likes' => 0
		);
		
		$this->db->insert('posts',$insertdata);
	}
	
	public function getPostsForUser($userid)
	{
		$query=$this->db->query("select * from posts where userid IN(select following 
								 from relationships where userid=$userid)");
		return $query->result();
	}
	
	public function getOwnPosts($userid)
	{
		$query=$this->db->query("select * from posts where userid=$userid");
		return $query->result();
	}
	
	
	public function like($postid)
	{	
		$insertdata = array(
						'userid' => $this->session->userdata('userid'),
						'postid' => (int)$postid
							);
		
		$query=$this->db->query("update posts set likes=likes+1 where postid=$postid ");
		$insert=$this->db->insert('postlikes',$insertdata);
	}
	
	public function getlikes($userid)
	{
		$res = $this->db->get_where('postlikes',array('userid' => $userid));
		return $res->result();
	}
	
	public function unlike($postid)
	{
		$query=$this->db->query("update posts set likes=likes-1 where postid=$postid ");
		$deletedata=array(
						'userid' => $this->session->userdata('userid'),
						'postid' => $postid
					);
		$res = $this->db->delete('postlikes', $deletedata);
	}
	
	
}
?>