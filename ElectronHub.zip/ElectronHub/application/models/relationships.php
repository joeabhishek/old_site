<?php

class relationships extends CI_Model{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		//$this->load->library('session');
	}
	
	public function getFollowingYou($userid)
	{
		$query=$this->db->get_where('relationships',array('following'=>$userid));
		return $query->result();
	}
	
	public function getYouFollowing($userid)
	{
		$query=$this->db->get_where('relationships',array('userid'=>$userid));
		return $query->result();
	}
	
	public function insertUser($currentuser, $user_id)
	{
		$data = array(
				'userid' => (int)$currentuser,
				'following' => (int)$user_id
					);
		
	    $this->db->insert('relationships',$data);
	}
	
	public function deleteUser($currentuser,$userid)
	{
		$data = array(
				'userid'=>(int)$currentuser ,
				'following'=> (int)$userid
					  );
		$this->db->delete('relationships',$data);
	}
	public function isFollowing($userid, $following){
		$query = $this->db->get_where('relationships', array('userid'=>$userid, 'following'=>$following));
		return $query->result();
	}
	
}
?>