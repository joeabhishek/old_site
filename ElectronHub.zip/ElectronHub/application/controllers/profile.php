<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->model('users');
		$this->load->model('posts');
		$this->load->model('relationships');
	}
	
	public function index()
	{
		
	}
	
	public function view($userid)
	{
		$email=$this->session->userdata('email');
		$data['currentuser']=$email;
		
		$userinfo=$this->users->getUserById($userid);
		$data['userinfo']=$userinfo;
		
		//$userid=$this->session->userdata('userid');
		$posts =$this->posts->getOwnPosts($userid);
        $data['posts']=$posts;
        
		$this->load->view("profile",$data);
	}

  public function followingyou(){
   		$email = $this->session->userdata('email');
        $data['currentuser'] = $email;     
        $res = $this->users->getUserByEmail($email);
        $userid = $res[0]->id;
        $following_you = $this->relationships->getFollowingYou($userid);
        $followingusers = array();

        foreach ($following_you as $object)
        {
        	$followinguser = $this->users->getUserById($object->userid);
        	if(count($this->relationships->isFollowing($userid, $object->userid)) == 0){
        		$followinguser[0]->notfollowing = 'true';
         	}
        	$followingusers[]=$followinguser;
        }
		
        $data['followingyou']=$followingusers;
        $this->load->view('followingyou',$data);
	}

	public function youfollowing()
	{
		$email=$this->session->userdata('email');
		$data['currentuser']=$email;
		$res=$this->users->getUserByEmail($email);
		$userid=$res[0]->id ;
		$you_following=$this->relationships->getYouFollowing($userid);
		$youfollowing=array();
				
		foreach($you_following as $object)
		{
			$youfollowing[]=$this->users->getUserById($object->following);
		}

		$data['youfollowing']=$youfollowing;
		$this->load->view('youfollowing',$data);
	}
	
}
