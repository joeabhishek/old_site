<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Follow extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('session');
	}
	
	public function followUser()
	{
		$currentuser = $this->session->userdata('userid');
		$this->load->model('relationships');
		$this->relationships->insertUser($currentuser, $this->input->post('userid'));
	}
	
	public function unfollowUser()
	{
		$currentuser = $this->session->userdata('userid');
		
		$this->load->model('relationships');
		$this->relationships->deleteUser($currentuser,$this->input->post('user_id'));
	}
}
