<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct()
  {
      parent::__construct();
      $this->load->library('ion_auth');
      $this->load->library('session');
      $this->load->helper('url');

      $this->load->database();
      
      $this->lang->load('auth');
      $this->load->helper('language');
  }

	public function index()
	{
  	  if($this->ion_auth->logged_in()){
          $email = $this->session->userdata('email');
          $data['currentuser'] = $email; 
          $this->load->model('users');
          $this->load->model('relationships');
          $this->load->model('posts');
          $query=$this->users->getUserByEmail($email);
          $this->session->set_userdata(array('userid'=>$query[0]->id)); 
          $allusers = $this->users->getUsers();
          $youfollowing = $this->relationships->getYouFollowing($query[0]->id);
          $unfollowedusers = array();
          
          foreach ($allusers as $user){
          		$inlist = false;
              if($user->id == $query[0]->id){
                  $inlist = true;
              }
            	foreach ($youfollowing as $yfuser) {
              		if($user->id == $yfuser->following){
            				  $inlist=true;
            				  break;
              		}
          		}
          		if(!$inlist)
          		   $unfollowedusers[] = $user;
          }

          $data['unfollowedusers'] = $unfollowedusers;
          $posts = $this->posts->getPostsForuser($query[0]->id);
          $likes = $this->posts->getlikes($query[0]->id);
          
          foreach ($likes as $item){
              foreach ($posts as $post) {
                  if($item->postid == $post->postid){
                      $post->likedByUser = true;
                  }
              }
          }

          $data['posts']=$posts;
          $this->load->view('home', $data);
      } 
      else{
          redirect("auth/login", refresh);
      }
  	}
}
?>

