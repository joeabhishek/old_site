<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Post extends CI_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->model('posts');
		$this->load->model('users');
		
	}
	
	public function create(){
		$posttext = $this->input->post('posttext');
		$user=$this->users->getUserById($this->session->userdata('userid'));
		$username= $user[0]->first_name . " " . $user[0]->last_name;
		$this->posts->createPost($username,$posttext);
	}
	
	public function like(){
		$postid=$this->input->post('postid');
		$this->posts->like($postid);
	}

	public function unlike(){
		$postid=$this->input->post('postid');
		$this->posts->unlike($postid);
	}
}

?>
