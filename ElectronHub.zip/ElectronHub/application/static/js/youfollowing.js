$(document).ready(function(){
	$('#followingyou .unfollowuser').click(function(){
		var user_id=$(this).attr('id');
		$.ajax(
		{
			url : '/fusionhub/index.php/follow/unfollowUser' ,
			type : 'POST',
			data : {user_id : user_id}
		}).done(function(){
			location.reload(true);
		});
	});
});