$(document).ready(function(){
	$('#postbtn').click(function(){
	   var post_text = $('#tweetBox textarea').val();
	   
	   $.ajax({
		   url : '/fusionhub/index.php/post/create',
		   type : 'POST',
		   data : {posttext: post_text}
	   }).done(function(data){
		  location.reload(true);
	   });
	});
	
	$('#suggestions .follow-btn').click(function(){
		var user_id=$(this).attr('id');
		$.ajax({
			url : '/fusionhub/index.php/follow/followUser',
			type : 'POST' ,
			data : {userid : user_id}
		}).done(function(data){
			//console.log(data)
			location.reload(true);
		});
	});


	$('#postslist .likebtn').click(function(){
		
		var postid=$(this).attr('id');
		$.ajax({
			url : '/fusionhub/index.php/post/like',
			type : 'POST',
			data : {postid : postid}
		}).done(function(data){
			location.reload(true);
		});
	});

		$('#postslist .unlikebtn').click(function(){
		
		var postid=$(this).attr('id');
		$.ajax({
			url : '/fusionhub/index.php/post/unlike',
			type : 'POST',
			data : {postid : postid}
		}).done(function(data){
			debugger
			location.reload(true);
		});

	});

});