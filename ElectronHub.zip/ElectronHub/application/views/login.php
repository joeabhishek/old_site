<html>
  <head>
    <title>Electron Hub | Login</title>
    <link rel="stylesheet" href="application/static/css/bootstrap.min.css" >
    <link rel="stylesheet" href="application/static/css/bootstrap-responsive.min.css" >
  </head>
  
  <body>
  <div class="hero-unit">
  <h1>Electron Hub</h1>
  <p>Fusion Charts Social Space</p>
  </div>
  <script type="text/javascript" src="application/static/js/jquery.min.js"></script>
  <script type="text/javascript" src="application/static/js/bootstrap.js"></script>
  </body>
  

</html>

