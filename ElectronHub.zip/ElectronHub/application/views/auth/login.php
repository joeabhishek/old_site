<!DOCTYPE html>
<html>
  <head>
    <title>Fusion Hub | Login</title>
    <link rel="stylesheet" href="/fusionhub/application/static/css/bootstrap.min.css" >
    <link rel="stylesheet" href="/fusionhub/application/static/css/bootstrap-responsive.min.css" >
    <link rel="stylesheet" href="/fusionhub/application/static/css/home.css" >
  </head>
  
  <body>
    <div class="hero-unit">
      <h1> Fusion Hub </h1>
        <p> A social space for FusionCharters xD</p>
      </h3>
    </div>
 
    <div class="container-fluid">
      <div class="row-fluid">
          <div class="span8">
          </div>
          <div class="span4">
            
            <?php if($message != ""): ?>
                <div id="infoMessage" class="alert alert-success"><?php echo $message;?></div>
            <?php endif ?>
            
            <h1><?php echo lang('login_heading');?></h1>
            <p><?php echo lang('login_subheading');?></p>

            <?php echo form_open("auth/login");?>

              <p>
                <?php echo lang('login_identity_label', 'indentity');?>
                <?php echo form_input($identity);?>
              </p>

              <p>
                <?php echo lang('login_password_label', 'password');?>
                <?php echo form_input($password);?>
              </p>

              <p><?php echo form_submit('submit', lang('login_submit_btn'));?></p>

            <?php echo form_close();?>

            <p><a href="create_user">Register</a></p>
            <p><a href="forgot_password"><?php echo lang('login_forgot_password');?></a></p>
          </div>
      </div>
    </div>

  <script type="text/javascript" src="/fusionhub/application/static/js/jquery.min.js"></script>
  <script type="text/javascript" src="/fusionhub/application/static/js/bootstrap.js"></script>
  <script type="text/javascript" src="/fusionhub/application/static/js/home.js"></script>
 
  </body>
</html>