<html>
  <head>
    <title>Electron Hub | Following</title>
    <link rel="stylesheet" href="/electronhub/application/static/css/bootstrap.min.css" >
    <link rel="stylesheet" href="/electronhub/application/static/css/bootstrap-responsive.min.css" >
    <link rel="stylesheet" href="/electronhub/application/static/css/home.css" >
  
  </head>
  
  <body>
    <div class="container-fluid">
      <div class="row-fluid" id="header">
        <div class="span3">
          <h3> Electron Hub </h3>
        </div>
        <div id="infobar" class="span3 offset6">
          <p><a id href="/electronhub/index.php/profile/view/<?php echo $this->session->userdata('userid');?>"><?php echo $currentuser ?></a> |<a href="auth/logout">LogOut</a>
          </p>
        </div>
      </div>
      
      <div class="row-fluid">
      <div class="span2">
      	<ul class="nav nav-list">
      		<li><a href="/electronhub/index.php/welcome" >Home</a></li>
      		<li><a href="/electronhub/index.php/profile/followingyou">Following You</a></li>
      		<li><a href="/electronhub/index.php/profile/youfollowing">You Following </a></li>
      	</ul>
      </div>
      <div class="span7">
       <?php foreach ($userinfo as $userdetails): ?>
            <h3><?php echo $userdetails->first_name . $userdetails->last_name ?></h3>
            <p><i class="icon-briefcase"></i> Company - <?php echo $userdetails->company ?></p>
            <p><i class="icon-envelope"></i> E-Mail - <?php echo $userdetails->email ?></p>
       <?php endforeach ?>
       <hr />
       <?php if(count($posts)<1) : ?>
        <div class="alert"><p>This user has not posted anything!!</p></div>
       <?php endif ?>
       <?php foreach ($posts as $post) :?>
      		  	<ul id="postslist">
      		    
      		    <li>
      		      <span class=" badge badge-inverse postDate"><i class="icon-time icon-white"></i></span><?php echo  date("d-m-Y", strtotime($post->date)); ?>
      		      <span class="badge badge-inverse postLikes"><i class="icon-heart icon-white"></i></span><?php echo $post->likes?>
      		    </li>
      		    <li class="postText"><p><?php echo $post->post_text?></p></li>  
      		    <li><button id="<?php echo $post->postid ?>" class="likebtn btn btn-primary btn-mini"><i class="icon-thumbs-up icon-white"></i> Like</button></li>
      		    
      		    </ul><br />
       <?php endforeach;?>
      
      
      </div>
      </div>
    </div>
    
    
  <script type="text/javascript" src="/electronhub/application/static/js/jquery.min.js"></script>
  <script type="text/javascript" src="/electronhub/application/static/js/bootstrap.js"></script>
  <script type="text/javascript" src="/electronhub/application/static/js/home.js"></script>
  </body>
</html>